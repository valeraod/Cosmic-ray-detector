// ============================================================
// camera.js — доступ к камере (getUserMedia), список устройств,
// главный цикл захвата кадров, таймер сессии и калибровка шума.
// ============================================================

async function startCamera(deviceId) {
  try {
    const videoConstraints = {
      width: { ideal: 640 },
      height: { ideal: 480 }
    };
    if (deviceId) {
      // конкретное устройство выбрано пользователем из списка
      videoConstraints.deviceId = { exact: deviceId };
    } else {
      // по умолчанию просим заднюю камеру (её обычно и заклеивают),
      // ideal — чтобы не было hard-фейла на устройствах без задней камеры
      videoConstraints.facingMode = { ideal: 'environment' };
    }

    stream = await navigator.mediaDevices.getUserMedia({
      video: videoConstraints,
      audio: false
    });
    video.srcObject = stream;
    await video.play();
    view.width = video.videoWidth || 640;
    view.height = video.videoHeight || 480;

    const track = stream.getVideoTracks()[0];
    const settings = track.getSettings();
    currentDeviceId = settings.deviceId || deviceId || null;

    await populateCameraList();

    running = true;
    startTime = Date.now();
    lastFrameChecksum = null;
    lastFrameChangeTs = Date.now();
    freezeWarn.classList.remove('show');
    startBtn.disabled = true;
    stopBtn.disabled = false;
    calibBtn.disabled = false;
    startFreezeWatchdog();
    loop();
    updateTimer();
  } catch (err) {
    alert('Не удалось получить доступ к камере: ' + err.message);
  }
}

// watchdog заморозки потока: если браузер поддерживает
// requestVideoFrameCallback — подписываемся на реальные события прихода
// декодированного кадра от камеры (см. комментарий в state.js). Иначе
// rvfcSupported остаётся false, и detection.js сам переключится на старый
// способ по чек-сумме пикселей.
function startFreezeWatchdog() {
  rvfcSupported = typeof video.requestVideoFrameCallback === 'function';
  lastVideoFrameTs = Date.now();
  if (!rvfcSupported) return;

  const onVideoFrame = () => {
    lastVideoFrameTs = Date.now();
    if (running) rvfcId = video.requestVideoFrameCallback(onVideoFrame);
  };
  rvfcId = video.requestVideoFrameCallback(onVideoFrame);
}

function stopFreezeWatchdog() {
  if (rvfcId != null && typeof video.cancelVideoFrameCallback === 'function') {
    video.cancelVideoFrameCallback(rvfcId);
  }
  rvfcId = null;
}

// перерисовывает канвас последним статичным кадром без анализа — нужно,
// когда камера остановлена (analyzeFrame не крутится сам) и надо убрать
// с картинки отметку выбранного в логе события, не запуская весь цикл заново
function redrawStaticFrame() {
  try { ctx.drawImage(video, 0, 0, view.width, view.height); } catch (e) { /* нет кадра — просто ничего не делаем */ }
}

// список камер доступен только после первого разрешения (иначе label пустые);
// поэтому список строим/обновляем уже после успешного getUserMedia
async function populateCameraList() {
  try {
    const devices = await navigator.mediaDevices.enumerateDevices();
    const videoInputs = devices.filter(d => d.kind === 'videoinput');
    if (videoInputs.length <= 1) {
      cameraRow.style.display = 'none';
      return;
    }
    cameraSelect.innerHTML = '';
    videoInputs.forEach((d, i) => {
      const opt = document.createElement('option');
      opt.value = d.deviceId;
      opt.textContent = d.label || `Камера ${i + 1}`;
      if (d.deviceId === currentDeviceId) opt.selected = true;
      cameraSelect.appendChild(opt);
    });
    cameraRow.style.display = 'flex';
  } catch (err) {
    // enumerateDevices может быть недоступен в редких браузерах — не критично,
    // просто не показываем селектор
    cameraRow.style.display = 'none';
  }
}

async function switchCamera(deviceId) {
  const wasRunning = running;
  if (stream) stream.getTracks().forEach(t => t.stop());
  if (raf) cancelAnimationFrame(raf);
  stopFreezeWatchdog();
  running = false;
  // координаты горячих пикселей привязаны к конкретному сенсору/кадрированию —
  // при смене камеры прошлая калибровка не валидна
  hotPixels.clear();
  if (wasRunning) {
    await startCamera(deviceId);
  }
}

function stopCamera() {
  running = false;
  if (raf) cancelAnimationFrame(raf);
  stopFreezeWatchdog();
  if (stream) stream.getTracks().forEach(t => t.stop());
  freezeWarn.classList.remove('show');
  startBtn.disabled = false;
  stopBtn.disabled = true;
  calibBtn.disabled = true;
}

function loop(ts) {
  if (!running) return;
  raf = requestAnimationFrame(loop);
  if (!ts || ts - lastFrameTime < FRAME_INTERVAL) return;
  lastFrameTime = ts;
  analyzeFrame();
}

function updateTimer() {
  if (!running) return;
  const elapsed = Math.floor((Date.now() - startTime) / 1000);
  const m = Math.floor(elapsed / 60);
  const s = elapsed % 60;
  statTime.textContent = m + ':' + String(s).padStart(2, '0');
  setTimeout(updateTimer, 1000);
}

async function calibrate() {
  calibBtn.disabled = true;
  calibBtn.textContent = 'Калибровка...';
  const counts = new Map();
  const samples = 25;

  for (let s = 0; s < samples; s++) {
    ctx.drawImage(video, 0, 0, view.width, view.height);
    const frame = ctx.getImageData(0, 0, view.width, view.height);
    const data = frame.data;
    for (let i = 0; i < data.length; i += 4) {
      const brightness = (data[i] + data[i+1] + data[i+2]) / 3;
      if (brightness >= threshold) {
        const px = (i / 4) % view.width;
        const py = Math.floor((i / 4) / view.width);
        if (px < EDGE_MARGIN || px >= view.width - EDGE_MARGIN || py < EDGE_MARGIN || py >= view.height - EDGE_MARGIN) {
          continue;
        }
        const key = px + ',' + py;
        counts.set(key, (counts.get(key) || 0) + 1);
      }
    }
    await new Promise(r => setTimeout(r, 150));
  }

  // пиксель, засветившийся в большинстве калибровочных кадров — "горячий" дефект матрицы,
  // а не случайная частица; такие исключаем из детекции
  hotPixels.clear();
  for (const [key, count] of counts.entries()) {
    if (count >= samples * 0.6) hotPixels.add(key);
  }

  calibBtn.textContent = `Калибровка (найдено ${hotPixels.size} горячих пикселей)`;
  setTimeout(() => {
    calibBtn.textContent = 'Калибровка шума (5с)';
    calibBtn.disabled = false;
  }, 2000);
}

startBtn.addEventListener('click', () => startCamera());
stopBtn.addEventListener('click', stopCamera);
calibBtn.addEventListener('click', calibrate);
cameraSelect.addEventListener('change', () => switchCamera(cameraSelect.value));
