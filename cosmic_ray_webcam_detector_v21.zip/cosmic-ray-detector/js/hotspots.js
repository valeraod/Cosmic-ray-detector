// ============================================================
// hotspots.js — адаптивное обучение и хранение шумных/дефектных
// точечных зон сенсора: кластеризация повторов, persist в
// localStorage, рендер панели "Зоны сенсора" и связанные
// обработчики (клики по списку и по кадру для ручной разметки).
// ============================================================

function loadHotspots() {
  try {
    const raw = localStorage.getItem(HOTSPOTS_STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : null;
    if (Array.isArray(parsed)) {
      // старый формат (только массив точек)
      hotspots = parsed;
    } else if (parsed) {
      // старые сохранения могли содержать ещё и bands — игнорируем их,
      // полосовое отсечение больше не поддерживается
      hotspots = parsed.hotspots || [];
    } else {
      hotspots = [];
    }
  } catch (e) {
    hotspots = [];
  }
}

function saveHotspots() {
  try {
    localStorage.setItem(HOTSPOTS_STORAGE_KEY, JSON.stringify({ hotspots }));
  } catch (e) { /* localStorage недоступен — просто не сохраняем между сессиями */ }
}

function findHotspot(x, y) {
  let best = null, bestDist = Infinity;
  for (const h of hotspots) {
    const d = Math.hypot(h.x - x, h.y - y);
    if (d <= HOTSPOT_CLUSTER_RADIUS && d < bestDist) { best = h; bestDist = d; }
  }
  return best;
}

function isInExcludedZone(x, y) {
  for (const h of hotspots) {
    if (h.excluded && Math.hypot(h.x - x, h.y - y) <= EXCLUSION_RADIUS) return true;
  }
  return false;
}

function excludedZoneCount() {
  return hotspots.filter(h => h.excluded).length;
}

function toggleHotspot(idx) {
  const h = hotspots[idx];
  if (!h) return;
  h.excluded = !h.excluded;
  if (h.excluded) h.count = Math.max(h.count, REPEAT_THRESHOLD);
  saveHotspots();
  renderHotspotList();
  statZones.textContent = excludedZoneCount();
}

function deleteHotspot(idx) {
  hotspots.splice(idx, 1);
  saveHotspots();
  renderHotspotList();
  statZones.textContent = excludedZoneCount();
}

function renderHotspotList() {
  const totalCount = hotspots.length;
  hotspotPanelCount.textContent = totalCount ? `(${totalCount})` : '';

  if (totalCount === 0) {
    hotspotList.innerHTML = '<div class="log-empty">Пока нет обученных зон</div>';
    return;
  }

  const order = hotspots
    .map((h, idx) => ({ h, idx }))
    .sort((a, b) => (b.h.excluded - a.h.excluded) || (b.h.count - a.h.count));

  const pointsHtml = order.map(({ h, idx }) => `
    <div class="hotspot-item">
      <span class="hotspot-dot${h.excluded ? ' excluded' : ''}"></span>
      <span class="coords">x=${Math.round(h.x)}, y=${Math.round(h.y)}</span>
      <span class="count">×${h.count}</span>
      <span class="status ${h.excluded ? 'excluded' : 'learning'}">${h.excluded ? 'исключена' : 'учится'}</span>
      <button data-action="toggle" data-idx="${idx}">${h.excluded ? 'вернуть' : 'исключить'}</button>
      <button data-action="delete" data-idx="${idx}">забыть</button>
    </div>
  `).join('');

  hotspotList.innerHTML = pointsHtml;
}

hotspotList.addEventListener('click', (e) => {
  const btn = e.target.closest('button[data-idx]');
  if (!btn) return;
  if (btn.dataset.action === 'toggle') toggleHotspot(Number(btn.dataset.idx));
  else if (btn.dataset.action === 'delete') deleteHotspot(Number(btn.dataset.idx));
});

// клик прямо по кадру — ручная отметка дефектной точки, для случаев,
// когда пользователь уже сам знает координаты проблемного пикселя
// (например, разглядев его на сохранённых фото событий). Обычный клик по
// кадру теперь используется для другого действия — выделения события в
// логе (см. ui.js), поэтому разметка дефекта требует Shift+клик, чтобы два
// разных действия не конфликтовали на одном и том же жесте.
view.addEventListener('click', (e) => {
  if (!e.shiftKey) return; // обычный клик без Shift — это выделение, не разметка дефекта

  const rect = view.getBoundingClientRect();
  const scaleX = view.width / rect.width;
  const scaleY = view.height / rect.height;
  const x = Math.round((e.clientX - rect.left) * scaleX);
  const y = Math.round((e.clientY - rect.top) * scaleY);

  let hs = findHotspot(x, y);
  if (hs) {
    hs.excluded = true;
    hs.count = Math.max(hs.count, REPEAT_THRESHOLD);
  } else {
    hs = { x, y, count: REPEAT_THRESHOLD, excluded: true };
    hotspots.push(hs);
  }
  saveHotspots();
  renderHotspotList();
  statZones.textContent = excludedZoneCount();
});

resetHotspotsBtn.addEventListener('click', () => {
  if (!confirm('Забыть все обученные дефектные зоны сенсора? Придётся заново накопить повторы, чтобы их снова исключить.')) return;
  hotspots = [];
  saveHotspots();
  statZones.textContent = 0;
  renderHotspotList();
});

// первичная загрузка сохранённых зон при старте приложения
loadHotspots();
saveHotspots();
renderHotspotList();
statZones.textContent = excludedZoneCount();
