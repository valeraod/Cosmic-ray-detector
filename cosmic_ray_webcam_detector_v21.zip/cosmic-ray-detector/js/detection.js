// ============================================================
// detection.js — ядро анализа: покадровый скан яркости, watchdog
// заморозки потока, кластеризация засветок, геометрическая оценка
// формы (трек vs пятно) и регистрация событий в лог/историю.
// ============================================================

// грубая, но дешёвая контрольная сумма кадра: берём каждый ~197-й байт
// (взаимно простое с шириной строки число, чтобы не попасть в один и тот же столбец)
function frameChecksum(data) {
  let sum = 0;
  for (let i = 0; i < data.length; i += 197) sum = (sum + data[i]) & 0xffffffff;
  return sum;
}

// сэмплирует окрестность вокруг центра события (радиус HALO_RADIUS px) в сырых
// данных кадра — не только "да/нет по порогу", а реальные значения соседей.
// Нужно, чтобы отличать плавный спад яркости вокруг сильного попадания
// (растекание заряда / характерная форма трека) от резкого одиночного скачка
// без ореола — такие вещи не видно по одному пикселю выше основного порога,
// но хорошо видно по соседям чуть ниже него.
function sampleHalo(data, w, h, cx, cy, lowThreshold) {
  const cxr = Math.round(cx), cyr = Math.round(cy);
  let peakNeighbor = 0;
  let haloCount = 0;
  for (let dy = -HALO_RADIUS; dy <= HALO_RADIUS; dy++) {
    for (let dx = -HALO_RADIUS; dx <= HALO_RADIUS; dx++) {
      if (dx === 0 && dy === 0) continue;
      const x = cxr + dx, y = cyr + dy;
      if (x < 0 || x >= w || y < 0 || y >= h) continue;
      const idx = (y * w + x) * 4;
      const b = (data[idx] + data[idx + 1] + data[idx + 2]) / 3;
      if (b > peakNeighbor) peakNeighbor = b;
      if (b >= lowThreshold) haloCount++;
    }
  }
  return { peakNeighbor, haloCount };
}

function analyzeFrame() {
  ctx.drawImage(video, 0, 0, view.width, view.height);
  const frame = ctx.getImageData(0, 0, view.width, view.height);
  const data = frame.data;
  const w = view.width, h = view.height;

  let sum = 0;
  let maxBrightnessFrame = 0;
  let brightPixels = [];
  let faintCandidates = [];
  const lowThreshold = Math.max(MIN_LOW_THRESHOLD, threshold - LOW_THRESHOLD_DELTA);
  statLowThreshold.textContent = lowThreshold.toFixed(0);

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i], g = data[i+1], b = data[i+2];
    const brightness = (r + g + b) / 3;
    sum += brightness;
    if (brightness > maxBrightnessFrame) maxBrightnessFrame = brightness;

    if (brightness >= lowThreshold) {
      const px = (i / 4) % w;
      const py = Math.floor((i / 4) / w);
      // пропускаем самую кромку кадра — там сосед события может лежать
      // за пределами кадра, и форму пятна (для line/blob) оценить нечестно
      if (px < EDGE_MARGIN || px >= w - EDGE_MARGIN || py < EDGE_MARGIN || py >= h - EDGE_MARGIN) {
        continue;
      }
      const key = px + ',' + py;
      if (hotPixels.has(key) || isInExcludedZone(px, py)) continue;

      if (brightness >= threshold) {
        brightPixels.push({ x: px, y: py, brightness });
      } else {
        faintCandidates.push({ x: px, y: py, brightness });
      }
    }
  }

  const avgBrightness = sum / (w * h);
  statBg.textContent = avgBrightness.toFixed(1);
  statMax.textContent = maxBrightnessFrame.toFixed(0);
  statZones.textContent = excludedZoneCount();

  // watchdog заморозки видеопотока.
  // Основной способ (rvfcSupported === true): смотрим на lastVideoFrameTs,
  // который обновляет отдельный requestVideoFrameCallback-подписчик в
  // camera.js при каждом реально доставленном декодированном кадре. Это не
  // зависит от содержимого кадра, поэтому честная медленная выдача кадров
  // (например, длинная выдержка в темноте — типичный режим этого детектора)
  // не путается с настоящим зависанием потока.
  // Запасной способ (браузеры без rVFC): старая эвристика — если контрольная
  // сумма кадра не меняется дольше FREEZE_TIMEOUT, считаем поток зависшим.
  // У неё есть известное ограничение — в почти полностью тёмном кадре
  // чек-сумма может случайно не меняться по нескольку секунд без реального
  // зависания, поэтому используется только когда rVFC недоступен.
  const now = Date.now();
  let isFrozen;
  if (rvfcSupported) {
    isFrozen = now - lastVideoFrameTs > FREEZE_TIMEOUT;
  } else {
    const checksum = frameChecksum(data);
    if (checksum !== lastFrameChecksum) {
      lastFrameChecksum = checksum;
      lastFrameChangeTs = now;
    }
    isFrozen = now - lastFrameChangeTs > FREEZE_TIMEOUT;
  }
  freezeWarn.classList.toggle('show', isFrozen);

  // Предупреждение об утечке света: если фон в среднем слишком яркий,
  // единичные пиксели ничего не значат — это не темнота
  if (avgBrightness > 25) {
    lightWarn.classList.add('show');
  } else {
    lightWarn.classList.remove('show');
  }

  if (brightPixels.length > 0 && avgBrightness <= 25) {
    const clusters = clusterPixels(brightPixels);
    const frameTime = new Date(); // единое время кадра для всех кластеров этого кадра
    clusters.forEach(cluster => registerEvent(cluster, frameTime, false, data, w, h, lowThreshold));
  }

  // отдельно — слабые кандидаты в трек: ищем только среди пикселей,
  // которые не вошли ни в один обычный кластер выше основного порога.
  // Кластеризация здесь O(n²) по парам пикселей — при резком всплеске
  // шума (например, случайной засветке) кандидатов может стать очень
  // много, и без ограничения это подвесит кадр. Если пикселей больше
  // разумного предела — это и так уже не "слабый след", а вспышка
  // шума целиком, разбирать её как трек смысла нет.
  if (faintCandidates.length >= MIN_FAINT_TRACK_PIXELS && faintCandidates.length <= MAX_FAINT_CANDIDATES && avgBrightness <= 25) {
    const faintClusters = clusterPixels(faintCandidates, FAINT_CLUSTER_RADIUS);
    const frameTime = new Date();
    for (const cluster of faintClusters) {
      if (cluster.length < MIN_FAINT_TRACK_PIXELS) continue;
      const { shape, elongation } = computeShape(cluster);
      if (shape === 'line' && elongation >= FAINT_LINE_ELONGATION_MIN && hasLocalPeak(cluster)) {
        registerEvent(cluster, frameTime, true, data, w, h, lowThreshold);
      }
    }
  }

  // подсветка найденных пикселей прямо на канвасе для наглядности
  ctx.strokeStyle = '#F09995';
  ctx.lineWidth = 2;
  for (const p of brightPixels) {
    ctx.strokeRect(p.x - 4, p.y - 4, 8, 8);
  }

  // жёлтыми окружностями отмечаем места, где сенсор уже "засветился" —
  // сплошная окружность = зона окончательно исключена из анализа,
  // пунктирная и более тусклая = точка ещё "накапливает" повторы
  ctx.lineWidth = 1.5;
  for (const hs of hotspots) {
    ctx.beginPath();
    ctx.setLineDash(hs.excluded ? [] : [3, 3]);
    ctx.strokeStyle = hs.excluded ? 'rgba(255, 209, 0, 0.9)' : 'rgba(255, 209, 0, 0.4)';
    ctx.arc(hs.x, hs.y, hs.excluded ? EXCLUSION_RADIUS : 5, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.setLineDash([]);

  // подсветка события, выбранного в логе — рисуем поверх всего остального,
  // каждый кадр заново (пока камера работает), чтобы отметка не терялась
  // при следующей перерисовке видео
  if (selectedEventId != null) {
    const selEv = events.get(selectedEventId);
    if (selEv) drawSelectionMarker(selEv.x, selEv.y);
  }
}

// перекрестие вокруг координат выбранного в логе события — контрастный
// голубой цвет, которого больше нигде в оверлеях нет, чтобы не путать
// с жёлтыми зонами дефектов или красной подсветкой засветки в кадре
function drawSelectionMarker(x, y) {
  const r = 14;
  ctx.save();
  ctx.strokeStyle = '#3AD6FF';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(x - r - 8, y);
  ctx.lineTo(x - r + 2, y);
  ctx.moveTo(x + r - 2, y);
  ctx.lineTo(x + r + 8, y);
  ctx.moveTo(x, y - r - 8);
  ctx.lineTo(x, y - r + 2);
  ctx.moveTo(x, y + r - 2);
  ctx.lineTo(x, y + r + 8);
  ctx.stroke();
  ctx.restore();
}

// группирует яркие пиксели кадра в кластеры (union-find по расстоянию),
// чтобы несколько независимых засветок в одном кадре не схлопывались в один
// центроид где-то посередине между ними
function clusterPixels(pixels, radius = CLUSTER_RADIUS) {
  const n = pixels.length;
  const parent = Array.from({ length: n }, (_, i) => i);

  function find(i) {
    while (parent[i] !== i) {
      parent[i] = parent[parent[i]];
      i = parent[i];
    }
    return i;
  }
  function union(i, j) {
    const ri = find(i), rj = find(j);
    if (ri !== rj) parent[ri] = rj;
  }

  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      const dx = pixels[i].x - pixels[j].x;
      const dy = pixels[i].y - pixels[j].y;
      if (Math.hypot(dx, dy) <= radius) union(i, j);
    }
  }

  const groups = new Map();
  for (let i = 0; i < n; i++) {
    const root = find(i);
    if (!groups.has(root)) groups.set(root, []);
    groups.get(root).push(pixels[i]);
  }
  return Array.from(groups.values());
}

function computeShape(pixels) {
  const n = pixels.length;
  if (n < MIN_PIXELS_FOR_SHAPE) return { shape: 'na', elongation: null };

  const mx = pixels.reduce((s, p) => s + p.x, 0) / n;
  const my = pixels.reduce((s, p) => s + p.y, 0) / n;
  let sxx = 0, syy = 0, sxy = 0;
  for (const p of pixels) {
    const dx = p.x - mx, dy = p.y - my;
    sxx += dx * dx; syy += dy * dy; sxy += dx * dy;
  }
  sxx /= n; syy /= n; sxy /= n;

  const trace = sxx + syy;
  const det = sxx * syy - sxy * sxy;
  const disc = Math.sqrt(Math.max(0, (trace * trace) / 4 - det));
  const lambda1 = trace / 2 + disc; // дисперсия вдоль главной оси пятна
  const lambda2 = trace / 2 - disc; // вдоль второстепенной оси

  const elongation = lambda2 <= 1e-6 ? 99 : lambda1 / lambda2;
  const shape = elongation >= LINE_ELONGATION_THRESHOLD ? 'line' : 'blob';
  return { shape, elongation };
}

// проверяет, что пик яркости кластера лежит ВНУТРИ вытянутого пятна, а не
// на одном из его концов. Настоящий трек частицы даёт нарастание яркости
// к точке максимальной ионизации и спад по обе стороны от неё. А гладкий
// монотонный градиент (виньетирование объектива к краю кадра, неполная
// компенсация экспозиции) даёт точно такую же высокую elongation по PCA,
// но яркость там растёт только в одну сторону — до самого конца пятна,
// без спада. Разница видна только если явно посмотреть на профиль
// яркости вдоль главной оси, а не только на её общую вытянутость.
function hasLocalPeak(pixels) {
  const n = pixels.length;
  if (n < 3) return true; // слишком мало точек, чтобы вообще судить о форме профиля

  const mx = pixels.reduce((s, p) => s + p.x, 0) / n;
  const my = pixels.reduce((s, p) => s + p.y, 0) / n;
  let sxx = 0, syy = 0, sxy = 0;
  for (const p of pixels) {
    const dx = p.x - mx, dy = p.y - my;
    sxx += dx * dx; syy += dy * dy; sxy += dx * dy;
  }
  sxx /= n; syy /= n; sxy /= n;

  // направление главной оси пятна (той самой, вдоль которой считалась elongation)
  const angle = 0.5 * Math.atan2(2 * sxy, sxx - syy);
  const ux = Math.cos(angle), uy = Math.sin(angle);

  // проекция каждого пикселя на эту ось, отсортированная по положению вдоль неё
  const projected = pixels
    .map(p => ({ t: (p.x - mx) * ux + (p.y - my) * uy, brightness: p.brightness }))
    .sort((a, b) => a.t - b.t);

  let peakIdx = 0;
  for (let i = 1; i < projected.length; i++) {
    if (projected[i].brightness > projected[peakIdx].brightness) peakIdx = i;
  }
  // пик должен быть строго внутри цепочки — не на первом и не на последнем
  // месте вдоль оси, иначе это монотонный градиент, а не нарастание-спад
  return peakIdx > 0 && peakIdx < projected.length - 1;
}

function registerEvent(pixels, frameTime, isFaint = false, data = null, w = 0, h = 0, lowThreshold = null) {
  eventCount++;
  statCount.textContent = eventCount;

  flashEl.classList.add('on');
  setTimeout(() => flashEl.classList.remove('on'), 90);

  const now = frameTime || new Date();
  const timeStr = now.toLocaleTimeString('ru-RU', { hour12: false }) + '.' +
    String(now.getMilliseconds()).padStart(3, '0');
  const area = pixels.length;
  const maxBrightness = Math.max(...pixels.map(p => p.brightness)).toFixed(0);
  const cx = pixels.reduce((s,p)=>s+p.x,0)/pixels.length;
  const cy = pixels.reduce((s,p)=>s+p.y,0)/pixels.length;

  // ореол вокруг события: соседи чуть ниже основного порога, которые сам
  // кластер не засчитал — по ним видно, есть ли плавный спад яркости
  // (растекание заряда / форма трека) или засветка резкая и одиночная
  const halo = data
    ? sampleHalo(data, w, h, cx, cy, lowThreshold != null ? lowThreshold : Math.max(MIN_LOW_THRESHOLD, threshold - LOW_THRESHOLD_DELTA))
    : { peakNeighbor: 0, haloCount: 0 };

  // проверяем, не попадает ли это событие в уже известную "проблемную" точку
  // сенсора (в пределах CLUSTER_RADIUS от ранее зафиксированной), и обучаем
  // адаптивную зону исключения — маркер события при этом всё равно остаётся
  // в логе, просто помечается как повтор
  let hs = findHotspot(cx, cy);
  let isRepeat = false;
  let justExcluded = false;
  if (hs) {
    hs.count++;
    isRepeat = true;
    if (!hs.excluded && hs.count >= REPEAT_THRESHOLD) {
      hs.excluded = true;
      justExcluded = true;
    }
  } else {
    hs = { x: cx, y: cy, count: 1, excluded: false };
    hotspots.push(hs);
  }
  saveHotspots();
  statZones.textContent = excludedZoneCount();
  renderHotspotList();
  // чтобы отличать от более уверенных многопиксельных/ярких засветок
  const isMarginal = area === 1 && (maxBrightness - threshold) <= 3;
  const { shape, elongation } = computeShape(pixels);

  const cropDataUrl = cropFrame(cx, cy);

  const eventId = nextEventId++;
  events.set(eventId, {
    isoTime: now.toISOString(),
    timeStr,
    area,
    maxBrightness,
    x: Math.round(cx),
    y: Math.round(cy),
    threshold,
    marginal: isMarginal,
    repeat: isRepeat,
    hotspotCount: hs.count,
    shape,
    elongation,
    faint: isFaint,
    haloCount: halo.haloCount,
    haloPeak: Math.round(halo.peakNeighbor),
    image: cropDataUrl
  });
  // держим бюджет памяти: при очень долгой шумной сессии не даём
  // events расти неограниченно — выкидываем самые старые записи.
  // Map хранит порядок вставки, так что первый ключ — самый старый.
  if (events.size > MAX_STORED_EVENTS) {
    events.delete(events.keys().next().value);
  }
  exportBtn.disabled = false;

  if (logEl.querySelector('.log-empty')) logEl.innerHTML = '';
  const item = document.createElement('div');
  item.className = 'log-item' + (isMarginal ? ' marginal' : '') + (isRepeat ? ' repeat' : '') + (shape === 'line' ? ' line-candidate' : '') + (isFaint ? ' faint-track' : '');
  item.dataset.eventId = eventId;
  let statusText = '';
  if (justExcluded) statusText = ` · 🔁 повтор ×${hs.count} — зона теперь исключена`;
  else if (isRepeat) statusText = ` · 🔁 повтор в этой точке (×${hs.count})`;
  else if (isMarginal) statusText = ' · пограничное';
  let shapeText = '';
  if (isFaint) shapeText = ` · 🔮 слабый трек-кандидат (ниже основного порога, вытянутость ${elongation.toFixed(1)})`;
  else if (shape === 'line') shapeText = ` · ⟋ похоже на трек (${elongation.toFixed(1)})`;
  else if (shape === 'blob') shapeText = ' · ● пятно';
  let haloText = '';
  if (halo.haloCount > 0) haloText = ` · 📉 спад к соседям (сосед до ${Math.round(halo.peakNeighbor)})`;
  item.innerHTML = `
    <img src="${cropDataUrl}" alt="кадр события" data-event-index="${eventId}">
    <span class="info">
      <span class="t">${timeStr}</span>
      <span class="a-text">area ${area}px, яркость ${maxBrightness}${statusText}${shapeText}${haloText}</span>
    </span>
    <span class="a">${isFaint ? '🔮' : (shape === 'line' ? '⟋' : (isMarginal || isRepeat ? '○' : '●'))}</span>`;
  logEl.prepend(item);

  // ограничим лог в DOM, но полную историю (в пределах MAX_STORED_EVENTS)
  // для экспорта храним в events
  while (logEl.children.length > 100) logEl.removeChild(logEl.lastChild);

  updateRate();
}

// вырезает квадратный фрагмент CROP_SIZE×CROP_SIZE вокруг координат (cx, cy) с текущего кадра
function cropFrame(cx, cy) {
  const half = CROP_SIZE / 2;
  let sx = Math.max(0, Math.min(Math.round(cx - half), view.width - CROP_SIZE));
  let sy = Math.max(0, Math.min(Math.round(cy - half), view.height - CROP_SIZE));

  const cropCanvas = document.createElement('canvas');
  cropCanvas.width = CROP_SIZE;
  cropCanvas.height = CROP_SIZE;
  const cropCtx = cropCanvas.getContext('2d');
  cropCtx.drawImage(view, sx, sy, CROP_SIZE, CROP_SIZE, 0, 0, CROP_SIZE, CROP_SIZE);
  return cropCanvas.toDataURL('image/png');
}

function updateRate() {
  const now = Date.now();
  eventTimestamps.push(now);
  eventTimestamps = eventTimestamps.filter(t => now - t < 60000);
  const perMin = eventTimestamps.length;
  statRate.textContent = perMin > 0 ? perMin + '/мин' : '–';
}
