// ============================================================
// ui.js — виджеты, не завязанные напрямую на детекцию/камеру:
// слайдер порога яркости и лайтбокс с деталями события.
// ============================================================

thresholdSlider.addEventListener('input', () => {
  threshold = parseInt(thresholdSlider.value, 10);
  thresholdInput.value = threshold;
});

// ручной ввод: применяем только валидное число в диапазоне слайдера,
// иначе откатываем поле к текущему threshold, не трогая состояние детектора
thresholdInput.addEventListener('change', () => {
  let v = parseInt(thresholdInput.value, 10);
  if (isNaN(v)) {
    thresholdInput.value = threshold;
    return;
  }
  v = Math.max(THRESHOLD_MIN, Math.min(THRESHOLD_MAX, v));
  threshold = v;
  thresholdSlider.value = v;
  thresholdInput.value = v;
});

// подсветка события прямо на живом (или последнем статичном) изображении с
// камеры — общая часть для лайтбокса и для обычного выбора строки в логе
function selectEvent(id) {
  const ev = events.get(id);
  if (!ev) return;
  selectedEventId = id;
  if (!running) drawSelectionMarker(ev.x, ev.y); // цикл analyzeFrame не крутится — рисуем сами
}

function deselectEvent() {
  if (selectedEventId == null) return;
  selectedEventId = null;
  if (!running) redrawStaticFrame(); // без этого отметка осталась бы висеть на статичной картинке навсегда
}

// просмотр увеличенного фото события прямо в приложении — только по клику
// на миниатюру. Заодно подсвечиваем координаты события на изображении с
// камеры, чтобы было видно, где на экране это произошло.
function openLightbox(id) {
  const ev = events.get(id);
  if (!ev) return;
  selectEvent(id);
  lightboxImg.src = ev.image;
  let statusLine = '–';
  if (ev.repeat) statusLine = `повтор в зоне (×${ev.hotspotCount})`;
  else if (ev.marginal) statusLine = 'пограничное';
  let shapeLine = 'н/д (мало пикселей)';
  if (ev.shape === 'line') shapeLine = `⟋ похоже на трек (вытянутость ${ev.elongation.toFixed(1)})`;
  else if (ev.shape === 'blob') shapeLine = `● пятно (вытянутость ${ev.elongation.toFixed(1)})`;
  let haloLine = 'нет — резкий одиночный пиксель';
  if (ev.haloCount) haloLine = `${ev.haloCount} соседних px (макс ${ev.haloPeak}) — есть спад`;
  lightboxMeta.innerHTML = `
    <span class="k">Время</span><span>${ev.timeStr}</span>
    <span class="k">Координаты</span><span>x=${ev.x}, y=${ev.y}</span>
    <span class="k">Площадь</span><span>${ev.area}px</span>
    <span class="k">Яркость</span><span>${ev.maxBrightness} (порог ${ev.threshold})</span>
    <span class="k">Статус</span><span>${statusLine}</span>
    <span class="k">Форма</span><span>${shapeLine}</span>
    <span class="k">Ореол</span><span>${haloLine}</span>
    <span class="k">Источник</span><span>${ev.faint ? '🔮 слабый трек (второй, низкий порог)' : 'обычный порог'}</span>`;
  lightbox.classList.add('show');
}

function closeLightbox() {
  lightbox.classList.remove('show');
  deselectEvent();
}

// три разные зоны клика по строке лога:
// - миниатюра фото -> открыть лайтбокс с полным кадром события
// - текст (время/описание) -> просто выделить событие на рабочем поле
// - остальное (иконка, отступы, пустое место в самом списке) -> снять выделение
logEl.addEventListener('click', (e) => {
  const img = e.target.closest('.log-item img');
  if (img) {
    const item = img.closest('.log-item[data-event-id]');
    if (item) openLightbox(Number(item.dataset.eventId));
    return;
  }
  const info = e.target.closest('.log-item .info');
  if (info) {
    const item = info.closest('.log-item[data-event-id]');
    if (item) selectEvent(Number(item.dataset.eventId));
    return;
  }
  deselectEvent();
});

lightboxClose.addEventListener('click', closeLightbox);
lightbox.addEventListener('click', (e) => {
  if (e.target === lightbox) closeLightbox(); // клик по тёмному фону вне карточки
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeLightbox();
});
