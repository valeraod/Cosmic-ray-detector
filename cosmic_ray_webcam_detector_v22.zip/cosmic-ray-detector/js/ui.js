// ============================================================
// ui.js — виджеты, не завязанные напрямую на детекцию/камеру:
// слайдер порога яркости и лайтбокс с деталями события.
// ============================================================

// слайдер работает в линейной "сырой" шкале 0-1000, которая преобразуется
// в порог 1-255 логарифмически (Math.exp/Math.log) — так низкие значения
// (1-20), которые обычно и нужны на малошумных сенсорах, занимают большую
// часть хода ползунка, а не сжаты в первые несколько процентов диапазона
const SLIDER_RAW_MAX = 1000;
const LOG_MIN = Math.log(THRESHOLD_MIN);
const LOG_MAX = Math.log(THRESHOLD_MAX);

function sliderPosToThreshold(pos) {
  const t = pos / SLIDER_RAW_MAX;
  return Math.round(Math.exp(LOG_MIN + t * (LOG_MAX - LOG_MIN)));
}

function thresholdToSliderPos(value) {
  const t = (Math.log(value) - LOG_MIN) / (LOG_MAX - LOG_MIN);
  return Math.round(t * SLIDER_RAW_MAX);
}

thresholdSlider.min = 0;
thresholdSlider.max = SLIDER_RAW_MAX;
thresholdSlider.value = thresholdToSliderPos(threshold);

thresholdSlider.addEventListener('input', () => {
  threshold = sliderPosToThreshold(parseInt(thresholdSlider.value, 10));
  thresholdInput.value = threshold;
});

// ручной ввод: применяем только валидное число в диапазоне слайдера,
// иначе откатываем поле к текущему threshold, не трогая состояние детектора
thresholdInput.addEventListener('change', () => {
  let v = parseInt(thresholdInput.value, 10);
  if (isNaN(v)) {
    thresholdInput.value = threshold;
    return;
  }
  v = Math.max(THRESHOLD_MIN, Math.min(THRESHOLD_MAX, v));
  threshold = v;
  thresholdSlider.value = thresholdToSliderPos(v);
  thresholdInput.value = v;
});

// подсветка события прямо на живом (или последнем статичном) изображении с
// камеры — общая часть для лайтбокса и для обычного выбора строки в логе.
// Заодно переводит фокус на саму строку в логе: подсвечивает её и
// прокручивает к ней список, если она не видна на экране.
function selectEvent(id) {
  const ev = events.get(id);
  if (!ev) return;
  selectedEventId = id;
  if (!running) drawSelectionMarker(ev.x, ev.y); // цикл analyzeFrame не крутится — рисуем сами

  const prevSelected = logEl.querySelector('.log-item.selected');
  if (prevSelected) prevSelected.classList.remove('selected');
  const item = logEl.querySelector(`.log-item[data-event-id="${id}"]`);
  if (item) {
    item.classList.add('selected');
    item.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
}

function deselectEvent() {
  if (selectedEventId == null) return;
  selectedEventId = null;
  if (!running) redrawStaticFrame(); // без этого отметка осталась бы висеть на статичной картинке навсегда
  const prevSelected = logEl.querySelector('.log-item.selected');
  if (prevSelected) prevSelected.classList.remove('selected');
}

// ищет ближайшее к (x,y) зарегистрированное событие в пределах CLICK_SELECT_RADIUS —
// используется кликом по кадру камеры без Shift (см. ниже)
function findEventNear(x, y) {
  let bestId = null, bestDist = CLICK_SELECT_RADIUS;
  for (const [id, ev] of events) {
    const d = Math.hypot(ev.x - x, ev.y - y);
    if (d <= bestDist) { bestId = id; bestDist = d; }
  }
  return bestId;
}

// клик по кадру камеры без Shift — выделение уже зарегистрированного события
// (переводит фокус на его строку в логе), а не разметка новой дефектной
// зоны (это отдельное действие по Shift+клику, см. hotspots.js). Если рядом
// с кликом нет ни одного события — ничего не происходит: это осознанно,
// чтобы случайный клик по пустому месту не сбрасывал текущее выделение.
view.addEventListener('click', (e) => {
  if (e.shiftKey) return; // Shift+клик — это разметка дефекта, см. hotspots.js

  const rect = view.getBoundingClientRect();
  const scaleX = view.width / rect.width;
  const scaleY = view.height / rect.height;
  const x = Math.round((e.clientX - rect.left) * scaleX);
  const y = Math.round((e.clientY - rect.top) * scaleY);

  const id = findEventNear(x, y);
  if (id != null) selectEvent(id);
});

// просмотр увеличенного фото события прямо в приложении — только по клику
// на миниатюру. Заодно подсвечиваем координаты события на изображении с
// камеры, чтобы было видно, где на экране это произошло.
function openLightbox(id) {
  const ev = events.get(id);
  if (!ev) return;
  selectEvent(id);
  lightboxImg.src = ev.image;
  let statusLine = '–';
  if (ev.repeat) statusLine = `повтор в зоне (×${ev.hotspotCount})`;
  else if (ev.marginal) statusLine = 'пограничное';
  let shapeLine = 'н/д (мало пикселей)';
  if (ev.shape === 'line') shapeLine = `⟋ похоже на трек (вытянутость ${ev.elongation.toFixed(1)})`;
  else if (ev.shape === 'blob') shapeLine = `● пятно (вытянутость ${ev.elongation.toFixed(1)})`;
  let haloLine = 'нет — резкий одиночный пиксель';
  if (ev.haloCount) haloLine = `${ev.haloCount} соседних px (макс ${ev.haloPeak}) — есть спад`;
  lightboxMeta.innerHTML = `
    <span class="k">Время</span><span>${ev.timeStr}</span>
    <span class="k">Координаты</span><span>x=${ev.x}, y=${ev.y}</span>
    <span class="k">Площадь</span><span>${ev.area}px</span>
    <span class="k">Яркость</span><span>${ev.maxBrightness} (порог ${ev.threshold})</span>
    <span class="k">Статус</span><span>${statusLine}</span>
    <span class="k">Форма</span><span>${shapeLine}</span>
    <span class="k">Ореол</span><span>${haloLine}</span>
    <span class="k">Источник</span><span>${ev.faint ? '🔮 слабый трек (второй, низкий порог)' : 'обычный порог'}</span>`;
  lightbox.classList.add('show');
}

function closeLightbox() {
  lightbox.classList.remove('show');
  deselectEvent();
}

// три разные зоны клика по строке лога:
// - миниатюра фото -> открыть лайтбокс с полным кадром события
// - текст (время/описание) -> просто выделить событие на рабочем поле
// - остальное (иконка, отступы, пустое место в самом списке) -> снять выделение
logEl.addEventListener('click', (e) => {
  const img = e.target.closest('.log-item img');
  if (img) {
    const item = img.closest('.log-item[data-event-id]');
    if (item) openLightbox(Number(item.dataset.eventId));
    return;
  }
  const info = e.target.closest('.log-item .info');
  if (info) {
    const item = info.closest('.log-item[data-event-id]');
    if (item) selectEvent(Number(item.dataset.eventId));
    return;
  }
  deselectEvent();
});

lightboxClose.addEventListener('click', closeLightbox);
lightbox.addEventListener('click', (e) => {
  if (e.target === lightbox) closeLightbox(); // клик по тёмному фону вне карточки
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeLightbox();
});
