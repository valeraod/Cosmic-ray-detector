// ============================================================
// export.js — сборка zip-архива с фото событий и events.csv
// (использует JSZip, подключённый в index.html до этого файла).
// ============================================================

async function exportZip() {
  exportBtn.disabled = true;
  const originalLabel = exportBtn.textContent;
  exportBtn.textContent = 'Собираю архив...';

  const zip = new JSZip();
  const imgFolder = zip.folder('images');

  let csv = 'timestamp,area_px,max_brightness,x,y,threshold,marginal,repeat,hotspot_count,shape,elongation,faint,image_file\n';
  let i = 0;
  for (const e of events.values()) {
    const filename = `event_${String(i + 1).padStart(4, '0')}.png`;
    const base64 = e.image.split(',')[1];
    imgFolder.file(filename, base64, { base64: true });
    csv += `${e.isoTime},${e.area},${e.maxBrightness},${e.x},${e.y},${e.threshold},${e.marginal ? 1 : 0},${e.repeat ? 1 : 0},${e.hotspotCount},${e.shape},${e.elongation != null ? e.elongation.toFixed(2) : ''},${e.faint ? 1 : 0},images/${filename}\n`;
    i++;
  }
  zip.file('events.csv', csv);

  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `cosmic_ray_events_${Date.now()}.zip`;
  a.click();
  URL.revokeObjectURL(url);

  exportBtn.textContent = originalLabel;
  exportBtn.disabled = false;
}

exportBtn.addEventListener('click', exportZip);
