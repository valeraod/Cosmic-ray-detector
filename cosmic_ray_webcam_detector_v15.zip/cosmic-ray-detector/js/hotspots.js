// ============================================================
// hotspots.js — адаптивное обучение и хранение шумных/дефектных
// зон сенсора: кластеризация повторов, полосовое отсечение краёв,
// persist в localStorage, рендер панели "Зоны сенсора" и связанные
// обработчики (клики по списку и по кадру для ручной разметки).
// ============================================================

function loadHotspots() {
  try {
    const raw = localStorage.getItem(HOTSPOTS_STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : null;
    if (Array.isArray(parsed)) {
      // старый формат (только массив точек) — оставляем как есть, полосы ещё не учились
      hotspots = parsed;
      excludedBands = { left: null, right: null, top: null, bottom: null };
    } else if (parsed) {
      hotspots = parsed.hotspots || [];
      excludedBands = parsed.bands || { left: null, right: null, top: null, bottom: null };
    } else {
      hotspots = [];
    }
  } catch (e) {
    hotspots = [];
  }
}

function saveHotspots() {
  try {
    localStorage.setItem(HOTSPOTS_STORAGE_KEY, JSON.stringify({ hotspots, bands: excludedBands }));
  } catch (e) { /* localStorage недоступен — просто не сохраняем между сессиями */ }
}

function findHotspot(x, y) {
  let best = null, bestDist = Infinity;
  for (const h of hotspots) {
    const d = Math.hypot(h.x - x, h.y - y);
    if (d <= HOTSPOT_CLUSTER_RADIUS && d < bestDist) { best = h; bestDist = d; }
  }
  return best;
}

// проверяет, не пора ли схлопнуть скопление краевых точек в полосу целиком
function collapseEdgeBandsIfNeeded() {
  const w = frameW, h = frameH;
  const excluded = hotspots.filter(hs => hs.excluded);

  function tryBand(side, matches, cutoffFn) {
    if (excludedBands[side] != null || matches.length < BAND_HOTSPOT_THRESHOLD) return;
    excludedBands[side] = cutoffFn(matches);
    // убираем точечные зоны, которые теперь и так покрыты полосой
    hotspots = hotspots.filter(hs => !matches.includes(hs));
  }

  tryBand('left',
    excluded.filter(hs => hs.x <= EDGE_BAND_PX),
    m => Math.max(...m.map(hs => hs.x)) + EXCLUSION_RADIUS);
  tryBand('right',
    excluded.filter(hs => hs.x >= w - EDGE_BAND_PX),
    m => Math.min(...m.map(hs => hs.x)) - EXCLUSION_RADIUS);
  tryBand('top',
    excluded.filter(hs => hs.y <= EDGE_BAND_PX),
    m => Math.max(...m.map(hs => hs.y)) + EXCLUSION_RADIUS);
  tryBand('bottom',
    excluded.filter(hs => hs.y >= h - EDGE_BAND_PX),
    m => Math.min(...m.map(hs => hs.y)) - EXCLUSION_RADIUS);
}

function isInExcludedZone(x, y) {
  if (excludedBands.left != null && x <= excludedBands.left) return true;
  if (excludedBands.right != null && x >= excludedBands.right) return true;
  if (excludedBands.top != null && y <= excludedBands.top) return true;
  if (excludedBands.bottom != null && y >= excludedBands.bottom) return true;
  for (const h of hotspots) {
    if (h.excluded && Math.hypot(h.x - x, h.y - y) <= EXCLUSION_RADIUS) return true;
  }
  return false;
}

function excludedZoneCount() {
  const bandCount = Object.values(excludedBands).filter(v => v != null).length;
  return hotspots.filter(h => h.excluded).length + bandCount;
}

function resetBand(side) {
  excludedBands[side] = null;
  saveHotspots();
  renderHotspotList();
  statZones.textContent = excludedZoneCount();
}

function toggleHotspot(idx) {
  const h = hotspots[idx];
  if (!h) return;
  h.excluded = !h.excluded;
  if (h.excluded) h.count = Math.max(h.count, REPEAT_THRESHOLD);
  collapseEdgeBandsIfNeeded();
  saveHotspots();
  renderHotspotList();
  statZones.textContent = excludedZoneCount();
}

function deleteHotspot(idx) {
  hotspots.splice(idx, 1);
  saveHotspots();
  renderHotspotList();
  statZones.textContent = excludedZoneCount();
}

function renderHotspotList() {
  const bandEntries = Object.entries(excludedBands).filter(([, v]) => v != null);
  const totalCount = hotspots.length + bandEntries.length;
  hotspotPanelCount.textContent = totalCount ? `(${totalCount})` : '';

  if (totalCount === 0) {
    hotspotList.innerHTML = '<div class="log-empty">Пока нет обученных зон</div>';
    return;
  }

  const bandsHtml = bandEntries.map(([side, cutoff]) => `
    <div class="hotspot-item">
      <span class="hotspot-dot excluded"></span>
      <span class="coords">полоса: ${BAND_LABELS[side]} (${side === 'left' || side === 'right' ? 'x' : 'y'} ${side === 'left' || side === 'top' ? '≤' : '≥'} ${Math.round(cutoff)}px)</span>
      <span class="status excluded">исключена</span>
      <button data-action="reset-band" data-side="${side}">вернуть</button>
    </div>
  `).join('');

  const order = hotspots
    .map((h, idx) => ({ h, idx }))
    .sort((a, b) => (b.h.excluded - a.h.excluded) || (b.h.count - a.h.count));

  const pointsHtml = order.map(({ h, idx }) => `
    <div class="hotspot-item">
      <span class="hotspot-dot${h.excluded ? ' excluded' : ''}"></span>
      <span class="coords">x=${Math.round(h.x)}, y=${Math.round(h.y)}</span>
      <span class="count">×${h.count}</span>
      <span class="status ${h.excluded ? 'excluded' : 'learning'}">${h.excluded ? 'исключена' : 'учится'}</span>
      <button data-action="toggle" data-idx="${idx}">${h.excluded ? 'вернуть' : 'исключить'}</button>
      <button data-action="delete" data-idx="${idx}">забыть</button>
    </div>
  `).join('');

  hotspotList.innerHTML = bandsHtml + pointsHtml;
}

hotspotList.addEventListener('click', (e) => {
  const btn = e.target.closest('button[data-idx], button[data-side]');
  if (!btn) return;
  if (btn.dataset.action === 'toggle') toggleHotspot(Number(btn.dataset.idx));
  else if (btn.dataset.action === 'delete') deleteHotspot(Number(btn.dataset.idx));
  else if (btn.dataset.action === 'reset-band') resetBand(btn.dataset.side);
});

// клик прямо по кадру — ручная отметка дефектной точки, для случаев,
// когда пользователь уже сам знает координаты проблемного пикселя
// (например, разглядев его на сохранённых фото событий)
view.addEventListener('click', (e) => {
  const rect = view.getBoundingClientRect();
  const scaleX = view.width / rect.width;
  const scaleY = view.height / rect.height;
  const x = Math.round((e.clientX - rect.left) * scaleX);
  const y = Math.round((e.clientY - rect.top) * scaleY);

  let hs = findHotspot(x, y);
  if (hs) {
    hs.excluded = true;
    hs.count = Math.max(hs.count, REPEAT_THRESHOLD);
  } else {
    hs = { x, y, count: REPEAT_THRESHOLD, excluded: true };
    hotspots.push(hs);
  }
  collapseEdgeBandsIfNeeded();
  saveHotspots();
  renderHotspotList();
  statZones.textContent = excludedZoneCount();
});

resetHotspotsBtn.addEventListener('click', () => {
  if (!confirm('Забыть все обученные дефектные зоны сенсора? Придётся заново накопить повторы, чтобы их снова исключить.')) return;
  hotspots = [];
  excludedBands = { left: null, right: null, top: null, bottom: null };
  saveHotspots();
  statZones.textContent = 0;
  renderHotspotList();
});

// первичная загрузка сохранённых зон при старте приложения
loadHotspots();
collapseEdgeBandsIfNeeded();
saveHotspots();
renderHotspotList();
statZones.textContent = excludedZoneCount();
