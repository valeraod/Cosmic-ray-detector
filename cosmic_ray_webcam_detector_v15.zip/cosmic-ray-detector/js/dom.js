// ============================================================
// dom.js — единая точка получения ссылок на DOM-элементы.
// Загружается после constants.js, но перед всеми модулями,
// которые их используют (hotspots/detection/camera/ui/export).
// ============================================================

const video = document.getElementById('video');
const view = document.getElementById('view');
const ctx = view.getContext('2d', { willReadFrequently: true });
const flashEl = document.getElementById('flash');
const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const calibBtn = document.getElementById('calibBtn');
const exportBtn = document.getElementById('exportBtn');
const thresholdSlider = document.getElementById('threshold');
const thresholdInput = document.getElementById('thresholdInput');
const lightWarn = document.getElementById('lightWarn');
const statCount = document.getElementById('statCount');
const statTime = document.getElementById('statTime');
const statBg = document.getElementById('statBg');
const statRate = document.getElementById('statRate');
const statMax = document.getElementById('statMax');
const statZones = document.getElementById('statZones');
const statLowThreshold = document.getElementById('statLowThreshold');
const resetHotspotsBtn = document.getElementById('resetHotspotsBtn');
const hotspotList = document.getElementById('hotspotList');
const hotspotPanelCount = document.getElementById('hotspotPanelCount');
const lightbox = document.getElementById('lightbox');
const lightboxImg = document.getElementById('lightboxImg');
const lightboxMeta = document.getElementById('lightboxMeta');
const lightboxClose = document.getElementById('lightboxClose');
const freezeWarn = document.getElementById('freezeWarn');
const logEl = document.getElementById('log');
const cameraRow = document.getElementById('cameraRow');
const cameraSelect = document.getElementById('cameraSelect');
